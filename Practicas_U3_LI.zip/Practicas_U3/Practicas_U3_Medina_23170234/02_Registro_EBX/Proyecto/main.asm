; Materia: Lenguajes de Interfaz - Unidad 3
; Alumno: Medina González Cristian Roberto
; Matrícula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. José Luis Medina Jiménez
; Práctica 02: Modificación de un registro desde un procedimiento
; Descripción: Suma cinco al valor de EBX y muestra el resultado.

INCLUDE Irvine32.inc

.data
    mensaje BYTE "Valor de EBX: ", 0

.code
main PROC
    mov ebx, 10
    call Procedimiento1

    ; El procedimiento deja su resultado en EBX: ahora vale quince.
    mov edx, OFFSET mensaje
    call WriteString

    ; WriteDec toma el número de EAX, por eso copiamos el resultado.
    mov eax, ebx
    call WriteDec
    call Crlf
    exit
main ENDP

; Entrada: EBX con el valor inicial. Salida: EBX aumentado en cinco.
; Modifica EBX y las banderas. No lo restauramos porque es el resultado.
Procedimiento1 PROC
    add ebx, 5
    ret
Procedimiento1 ENDP

END main

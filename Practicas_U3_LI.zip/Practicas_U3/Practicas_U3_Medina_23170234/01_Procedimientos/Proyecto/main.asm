; Materia: Lenguajes de Interfaz - Unidad 3
; Alumno: Medina González Cristian Roberto
; Matrícula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. José Luis Medina Jiménez
; Práctica 01: Llamadas a un procedimiento
; Descripción: Llama dos veces al mismo procedimiento y regresa a main.

INCLUDE Irvine32.inc

.data
    mensajeInicio BYTE "Inicio de programa", 0
    mensajeProcedimiento BYTE "Estoy dentro del procedimiento", 0
    mensajeFin BYTE "Fin del programa", 0

.code
main PROC
    mov edx, OFFSET mensajeInicio
    call WriteString
    call Crlf

    ; CALL guarda el punto de regreso antes de entrar al procedimiento.
    call mostrarAviso
    mov eax, 10

    ; Reutilizamos el mismo código. RET regresa a la siguiente instrucción.
    call mostrarAviso
    mov eax, 20

    mov edx, OFFSET mensajeFin
    call WriteString
    call Crlf

    ; Terminamos aquí para no seguir ejecutando el procedimiento de abajo.
    exit
main ENDP

; Entrada: ninguna. Salida: muestra un aviso.
; Modifica EDX y las banderas; no utiliza EAX como resultado.
mostrarAviso PROC
    mov edx, OFFSET mensajeProcedimiento
    call WriteString
    call Crlf
    ret
mostrarAviso ENDP

END main
